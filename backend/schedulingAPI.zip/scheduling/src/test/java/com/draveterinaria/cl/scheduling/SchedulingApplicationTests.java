package com.draveterinaria.cl.scheduling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulingApplicationTests {

	@Test
	void contextLoads() {
	}

}
